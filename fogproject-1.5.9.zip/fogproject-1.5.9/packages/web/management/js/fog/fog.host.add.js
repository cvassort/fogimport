var MACLookupTimer,
    MACLookupTimeout = 1000;
(function($) {
    $('#host-active-directory').show();
})(jQuery);
